<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$dbname = "Revised";
$mysqli = new mysqli($host, $dbuser, $dbpass, $dbname);

?>