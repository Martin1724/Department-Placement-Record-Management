<?php
	$conn=mysqli_connect("localhost","root","","Revised") or die("Could not connect to localhost");
	 mysql_select_db("") or die("could not connect to Login Details");
?>