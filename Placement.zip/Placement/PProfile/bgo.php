<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
<nav class="templatemo-left-nav">          
          <ul>
		  
<li><a href="ise.php"><i class="fa fa-home fa-fw"></i>ISE</a></li>
<li><a href="cse.php"><i class="fa fa-home fa-fw"></i>CSE</a></li>
<li><a href="ece.php"><i class="fa fa-home fa-fw"></i>ECE</a></li>
<li><a href="eee.php"><i class="fa fa-home fa-fw"></i>EEE</a></li>
<li><a href="cve.php"><i class="fa fa-home fa-fw"></i>CVE</a></li>
<li><a href="me.php"><i class="fa fa-home fa-fw"></i>ME</a></li>
<li><a href="bs.php"><i class="fa fa-home fa-fw"></i>BASIC SCIENCE</a></li>
          </ul>  
        </nav>
</body>
</html>